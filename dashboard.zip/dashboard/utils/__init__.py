"""Utilitaires pour le dashboard."""

