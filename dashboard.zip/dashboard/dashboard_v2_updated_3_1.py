"""
================================================================================
DASHBOARD INTERACTIF : PRÉDICTION DU PRIX DES MAISONS
================================================================================
Application Streamlit pour l'analyse et la prédiction des prix immobiliers
basée sur le dataset Kaggle "House Prices: Advanced Regression Techniques"
================================================================================
"""

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
import joblib
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import os
from pathlib import Path

# ============================================================================
# CONFIGURATION STREAMLIT
# ============================================================================

st.set_page_config(
    layout="wide",
    page_title="House Prices Prediction Dashboard",
    initial_sidebar_state="expanded"
)

# ============================================================================
# PERSONNALISATION DU THÈME ET DU STYLE
# ============================================================================

st.markdown("""
<style>
/* =========================
   SIDEBAR NAVIGATION BUTTONS
   ========================= */
[data-testid="stSidebar"] .stRadio input {
    display: none;
}
[data-testid="stSidebar"] .stRadio label {
    display: block;
    width: 100%;
    padding: 12px 16px;
    margin-bottom: 8px;
    border-radius: 8px;
    background-color: #ffffff;
    color: #2c3e50;
    cursor: pointer;
    font-size: 15px;
    font-weight: 500;
    border: 1px solid #e0e0e0;
    transition: background-color 0.2s ease, 
                color 0.2s ease, 
                border 0.2s ease;
}
[data-testid="stSidebar"] .stRadio label:hover {
    background-color: #e8f1fb;
    border-color: #1f77b4;
    color: #1f77b4;
}
[data-testid="stSidebar"] 
.stRadio input[type="radio"]:checked + div {
    background-color: #1f77b4;
    color: #ffffff;
    font-weight: 600;
    border-radius: 8px;
    padding: 12px 16px;
}
</style>
""", unsafe_allow_html=True)

# ============================================================================
# BARRE LATÉRALE – NAVIGATION
# ============================================================================
if "page" not in st.session_state:
    st.session_state.page = "Accueil"

st.sidebar.title("House Prices Dashboard")
st.sidebar.markdown("---")

pages = [
    "Accueil",
    "Exploration",
    "Analyse",
    "Modèle",
    "Simulateur",
    "Prédictions"
]

for p in pages:
    if st.sidebar.button(p, use_container_width=True):
        st.session_state.page = p

page = st.session_state.page

st.sidebar.markdown("---")
st.sidebar.info(
    "Ce dashboard analyse les facteurs influençant le prix des maisons "
    "et propose un modèle de prédiction basé sur XGBoost."
)

# ============================================================================
# CHARGEMENT DES DONNÉES ET DU MODÈLE - VERSION CORRECTE
# ============================================================================
DASHBOARD_DIR = Path(__file__).parent.absolute()

@st.cache_data
def load_data():
    """Charge les données d'entraînement nettoyées"""
    try:
        # Chercher train_clean.csv dans différents emplacements
        current_dir = Path(__file__).parent.absolute()
        possible_paths = [
            current_dir / "train_clean.csv",
            current_dir / "data" / "train_clean.csv",
            current_dir.parent / "train_clean.csv",
            Path.cwd() / "train_clean.csv"
        ]
        
        for path in possible_paths:
            if path.exists():
                df = pd.read_csv(path)
                
                # Remplissage des NaN pour les variables quantitatives clés
                for col in ['TotalBsmtSF', 'GarageArea', 'GarageCars', 'GrLivArea']:
                    if col in df.columns:
                        df[col] = df[col].fillna(0)
                
                st.sidebar.success(f" Données chargées: {path.name}")
                return df
        
        # Si train_clean.csv n'est pas trouvé, essayer avec train.csv
        train_path = current_dir / "train.csv"
        if train_path.exists():
            df = pd.read_csv(train_path)
            st.sidebar.warning("ℹ Chargement depuis train.csv (original)")
            return df
            
        st.sidebar.error(" Aucun fichier de données trouvé")
        return pd.DataFrame()
        
    except Exception as e:
        st.sidebar.error(f" Erreur chargement données: {e}")
        return pd.DataFrame()

@st.cache_resource
def load_model_results():
    results = {}

    # Chemins
    models_dir = DASHBOARD_DIR / "output" / "models"
    
    try:
        # 1. Charger le préprocesseur
        preprocessor_path = models_dir / "preprocessor.joblib"
        if preprocessor_path.exists():
            results["preprocessor"] = joblib.load(preprocessor_path)
            st.sidebar.success("✅ Préprocesseur chargé")
        else:
            st.sidebar.warning("⚠ preprocessor.joblib introuvable")
            
        # 2. Charger le modèle XGBoost (avec fallback sur l'ancien nom)
        model_path = models_dir / "best_model.joblib"
        if not model_path.exists():
            model_path = models_dir / "best_xgboost.joblib"
            
        if model_path.exists():
            results["model"] = joblib.load(model_path)
            st.sidebar.success(f"✅ Modèle XGBoost chargé ({model_path.name})")
        else:
            st.sidebar.warning("⚠ Modèle XGBoost introuvable")
        
        # 3. Charger les données pour calculer les métriques
        # Chercher le fichier train_clean.csv ou test.csv
        current_dir = Path(__file__).parent.absolute()
        test_data_path = current_dir / "test_clean.csv"
        
        if not test_data_path.exists():
            test_data_path = current_dir / "test.csv"
            
        if test_data_path.exists():
            test_df = pd.read_csv(test_data_path)
            
            # Séparez X_test et y_test si disponibles
            if 'SalePrice' in test_df.columns:
                X_test = test_df.drop('SalePrice', axis=1)
                y_test = test_df['SalePrice']
                
                # Appliquer le préprocesseur si disponible
                if 'preprocessor' in results and 'model' in results:
                    try:
                        X_test_processed = results["preprocessor"].transform(X_test)
                        y_pred = results["model"].predict(X_test_processed)
                        
                        # Convertir du log au prix réel si nécessaire
                        # (dépend de comment vos données ont été transformées)
                        if 'y_test' not in results:
                            results["y_test"] = y_test
                            results["y_pred"] = y_pred
                            
                        st.sidebar.success("✅ Prédictions calculées sur données de test")
                    except Exception as e:
                        st.sidebar.warning(f"⚠ Impossible de calculer prédictions: {e}")
                else:
                    st.sidebar.warning("⚠ Préprocesseur ou modèle manquant pour calcul")
            else:
                st.sidebar.warning("⚠ Colonne SalePrice manquante dans test.csv")
        else:
            st.sidebar.warning("⚠ Fichier de test non trouvé")
        
        # 4. Charger les fichiers existants si disponibles (fallback)
        y_test_path = models_dir / "y_test_log.npy"
        y_pred_path = models_dir / "y_pred_xgboost_log.npy"

        if y_test_path.exists() and y_pred_path.exists() and 'y_test' not in results:
            y_test_log = np.load(y_test_path)
            y_pred_log = np.load(y_pred_path)
            results["y_test"] = np.expm1(y_test_log)
            results["y_pred"] = np.expm1(y_pred_log)
            st.sidebar.success("✅ Prédictions chargées depuis fichiers")

        # 5. Feature importance
        analysis_dir = DASHBOARD_DIR / "output" / "analysis"
        importance_path = analysis_dir / "feature_importance_xgboost.csv"
        if importance_path.exists():
            results["importance"] = pd.read_csv(importance_path)
            st.sidebar.success("✅ Feature importance chargée")

        # 6. Soumission Kaggle
        predictions_dir = DASHBOARD_DIR / "output" / "predictions"
        submission_path = predictions_dir / "kaggle_submission_xgboost.csv"
        if submission_path.exists():
            results["submission"] = pd.read_csv(submission_path)
            st.sidebar.success("✅ Soumission Kaggle chargée")

    except Exception as e:
        st.sidebar.error(f"❌ Erreur lors du chargement: {e}")

    return results

@st.cache_data
def get_unique_values(df):
    """Extrait les valeurs uniques pour les variables qualitatives"""
    if df.empty:
        return {
            'neighborhoods': [],
            'house_styles': [],
            'kitchen_quals': [],
            'exterior_quals': [],
        }
    
    # Récupérer les valeurs uniques
    unique_data = {
        'neighborhoods': sorted(df['Neighborhood'].dropna().unique()) if 'Neighborhood' in df.columns else [],
        'house_styles': sorted(df['HouseStyle'].dropna().unique()) if 'HouseStyle' in df.columns else [],
        'kitchen_quals': sorted(df['KitchenQual'].dropna().unique()) if 'KitchenQual' in df.columns else [],
        'exterior_quals': sorted(df['ExterQual'].dropna().unique()) if 'ExterQual' in df.columns else [],
    }
    
    return unique_data

# ============================================================================
# CHARGEMENT EFFECTIF
# ============================================================================

# Chargement des données
df_raw = load_data()
model_data = load_model_results()

# Valeurs uniques et statistiques
if not df_raw.empty:
    unique_vals = get_unique_values(df_raw)
    avg_price = df_raw['SalePrice'].mean()
    median_price = df_raw['SalePrice'].median()
else:
    unique_vals = {'neighborhoods': [], 'house_styles': [], 'kitchen_quals': [], 'exterior_quals': []}
    avg_price = 0
    median_price = 0

# ============================================================================
# PAGE 1 : ACCUEIL
# ============================================================================
if page == "Accueil":
    st.title(" Prédiction du Prix des Maisons")
    st.markdown(
        "Bienvenue sur le dashboard analytique du projet **House Prices Prediction**. "
        "Explorez les données, analysez les relations, et découvrez comment notre modèle prédit le prix des maisons."
    )
    
    st.markdown("---")
    
    if not df_raw.empty:
        st.subheader(" Vue d'ensemble du Marché")
        
        # KPIs en colonnes
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Prix Moyen", f"${avg_price:,.0f}")
        with col2:
            st.metric("Prix Médian", f"${median_price:,.0f}")
        with col3:
            if 'GrLivArea' in df_raw.columns:
                st.metric("Surface Moyenne", f"{df_raw['GrLivArea'].mean():,.0f} sqft")
            else:
                st.metric("Nombre de Maisons", len(df_raw))
        with col4:
            if 'YearBuilt' in df_raw.columns:
                current_year = pd.Timestamp.now().year
                avg_age = current_year - df_raw['YearBuilt'].mean()
                st.metric("Âge Moyen", f"{avg_age:.0f} ans")
            else:
                st.metric("Variables", len(df_raw.columns))
        
        st.markdown("---")
        
        # Graphiques côte à côte
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Distribution des Prix")
            fig_hist = px.histogram(
                df_raw, x='SalePrice', nbins=50,
                title="Histogramme des Prix de Vente",
                labels={'SalePrice': 'Prix ($)', 'count': 'Nombre de maisons'},
                color_discrete_sequence=['#1f77b4']
            )
            fig_hist.update_layout(height=400, showlegend=False)
            st.plotly_chart(fig_hist, use_container_width=True)
        
        with col2:
            st.subheader("Résumé Statistique")
            fig_box = px.box(
                df_raw, y='SalePrice',
                title="Boxplot des Prix",
                labels={'SalePrice': 'Prix ($)'},
                color_discrete_sequence=['#ff7f0e']
            )
            fig_box.update_layout(height=400, showlegend=False)
            st.plotly_chart(fig_box, use_container_width=True)
    else:
        st.error(" Aucune donnée disponible. Veuillez vérifier que train_clean.csv existe.")

# ============================================================================
# PAGE 2 : EXPLORATION
# ============================================================================
elif page == "Exploration":
    st.title(" Exploration des Données")
    
    if df_raw.empty:
        st.error(" Aucune donnée disponible")
        st.stop()
    
    st.markdown("Analysez les relations entre les variables et le prix de vente.")
    st.markdown("---")
    
    tab1, tab2, tab3 = st.tabs(["Variables Quantitatives", "Variables Qualitatives", "Corrélations"])
    
    with tab1:
        st.subheader("Relation entre Variables Quantitatives et SalePrice")
        
        quant_vars = ['GrLivArea', 'TotalBsmtSF', 'GarageCars', 'OverallQual', 'YearBuilt']
        quant_vars = [v for v in quant_vars if v in df_raw.columns]
        
        selected_var = st.selectbox("Sélectionnez une variable :", quant_vars, key="quant_select")
        
        fig_scatter = px.scatter(
            df_raw, x=selected_var, y='SalePrice',
            title=f"SalePrice vs. {selected_var}",
            labels={'SalePrice': 'Prix ($)', selected_var: selected_var},
            trendline="ols",
            color_discrete_sequence=['#2ca02c']
        )
        fig_scatter.update_layout(height=500)
        st.plotly_chart(fig_scatter, use_container_width=True)
    
    with tab2:
        st.subheader("Impact des Variables Qualitatives")
        
        qual_vars = ['Neighborhood', 'HouseStyle', 'KitchenQual', 'ExterQual', 'MSZoning']
        qual_vars = [v for v in qual_vars if v in df_raw.columns]
        
        selected_qual = st.selectbox("Sélectionnez une variable qualitative :", qual_vars, key="qual_select")
        
        # Limiter à 20 catégories pour la lisibilité
        if df_raw[selected_qual].nunique() > 20:
            st.warning(f"La variable {selected_qual} a {df_raw[selected_qual].nunique()} catégories. Affichage des 20 plus fréquentes.")
            top_categories = df_raw[selected_qual].value_counts().head(20).index.tolist()
            df_filtered = df_raw[df_raw[selected_qual].isin(top_categories)]
        else:
            df_filtered = df_raw
        
        fig_qual = px.box(
            df_filtered, x=selected_qual, y='SalePrice',
            title=f"SalePrice par {selected_qual}",
            color=selected_qual if df_filtered[selected_qual].nunique() <= 10 else None
        )
        fig_qual.update_layout(
            height=600,
            xaxis_tickangle=-45
        )
        st.plotly_chart(fig_qual, use_container_width=True)
    
    with tab3:
        st.subheader("Matrice de Corrélation")
        
        # Sélectionner les variables numériques principales
        numeric_cols = df_raw.select_dtypes(include=[np.number]).columns.tolist()
        key_numeric = ['SalePrice', 'GrLivArea', 'TotalBsmtSF', 'GarageArea', 'GarageCars', 
                      'OverallQual', 'YearBuilt', 'FullBath', 'BedroomAbvGr']
        key_numeric = [col for col in key_numeric if col in numeric_cols]
        
        if len(key_numeric) > 1:
            corr_matrix = df_raw[key_numeric].corr()
            
            fig_corr, ax = plt.subplots(figsize=(10, 8))
            sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt=".2f", 
                       ax=ax, linewidths=.5, cbar_kws={'label': 'Corrélation'})
            ax.set_title('Matrice de Corrélation des Variables Clés')
            st.pyplot(fig_corr)
        else:
            st.warning("Pas assez de variables numériques pour la matrice de corrélation.")

# ============================================================================
# PAGE 3 : ANALYSE
# ============================================================================
elif page == "Analyse":
    st.title(" Analyse Temporelle et Géographique")
    
    if df_raw.empty:
        st.error(" Aucune donnée disponible")
        st.stop()
    
    st.markdown("Découvrez comment le temps et la localisation influencent les prix.")
    st.markdown("---")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if 'YrSold' in df_raw.columns:
            st.subheader("Évolution Temporelle")
            df_time = df_raw.groupby('YrSold')['SalePrice'].mean().reset_index()
            fig_time = px.line(
                df_time, x='YrSold', y='SalePrice',
                title="Prix Moyen par Année de Vente",
                markers=True,
                labels={'SalePrice': 'Prix Moyen ($)', 'YrSold': 'Année'}
            )
            fig_time.update_layout(height=400)
            st.plotly_chart(fig_time, use_container_width=True)
        else:
            st.info(" La variable 'YrSold' n'est pas disponible")
    
    with col2:
        if 'YearBuilt' in df_raw.columns:
            st.subheader("Année de Construction")
            fig_year = px.scatter(
                df_raw, x='YearBuilt', y='SalePrice',
                title="SalePrice vs. Année de Construction",
                trendline="ols",
                color_discrete_sequence=['#d62728']
            )
            fig_year.update_layout(height=400)
            st.plotly_chart(fig_year, use_container_width=True)
        else:
            st.info(" La variable 'YearBuilt' n'est pas disponible")

# ============================================================================
# PAGE 4 : MODÈLE
# ============================================================================
elif page == "Modèle":
    st.title(" Performance du Modèle XGBoost")
    
    if model_data is None:
        st.error(" Les données du modèle ne sont pas chargées.")
        st.stop()
    
    st.markdown("Évaluez la qualité des prédictions du modèle XGBoost.")
    st.markdown("---")
    
    if 'y_test' in model_data and 'y_pred' in model_data:
        y_test = model_data['y_test']
        y_pred = model_data['y_pred']
        
        # VALEURS FIXES - selon vos nouvelles métriques
        r2 = 0.91355          # R² Score
        rmse = 0.127014       # RMSE (dans l'échelle log?)
        mae = 0.007139        # MAE (dans l'échelle log?)
        n_samples = 292       # Nombre d'échantillons
        
        
        # Affichage des KPIs
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("R² Score", f"{r2:.4f}")
        with col2:
            st.metric("RMSE", f"{rmse:,.4f}")
        with col3:
            st.metric("MAE", f"{mae:,.4f}")
        with col4:
            st.metric("Échantillons", n_samples)
        
        st.markdown("---")
        
        # Graphiques de performance
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Valeurs Réelles vs. Prédites")
            fig_pred = px.scatter(
                x=y_test, y=y_pred,
                labels={'x': 'Prix Réel ($)', 'y': 'Prix Prédit ($)'},
                title='Prédictions vs. Réalité',
                trendline='ols'
            )
            min_val = min(y_test.min(), y_pred.min())
            max_val = max(y_test.max(), y_pred.max())
            fig_pred.add_trace(go.Scatter(
                x=[min_val, max_val],
                y=[min_val, max_val],
                mode='lines',
                name='Parfaite prédiction',
                line=dict(color='red', dash='dash')
            ))
            fig_pred.update_layout(height=400)
            st.plotly_chart(fig_pred, use_container_width=True)
        
        with col2:
            st.subheader("Distribution des Résidus")
            residuals = y_test - y_pred
            
            fig_res = px.histogram(
                residuals,
                nbins=30,
                title='Distribution des Erreurs de Prédiction',
                labels={'value': 'Erreur ($)'},
                color_discrete_sequence=['#ff7f0e']
            )
            fig_res.add_vline(x=0, line_dash="dash", line_color="red")
            fig_res.update_layout(height=400)
            st.plotly_chart(fig_res, use_container_width=True)
        
        # Afficher les valeurs exactes
        with st.expander("📊 Détails des métriques"):
            st.write(f"**R² Score (coefficient de détermination):** {r2:.4f}")
            st.write(f"**RMSE (Root Mean Square Error):** ${rmse:,.2f}")
            st.write(f"**MAE (Mean Absolute Error):** ${mae:,.2f}")
            st.write(f"**Taille de l'échantillon de test:** {n_samples} maisons")
            
            # Afficher un échantillon des prédictions
            st.write("**Échantillon des prédictions:**")
            sample_df = pd.DataFrame({
                'Prix Réel': y_test[:10],
                'Prix Prédit': y_pred[:10],
                'Erreur': y_test[:10] - y_pred[:10],
                'Erreur (%)': ((y_test[:10] - y_pred[:10]) / y_test[:10] * 100)
            })
            st.dataframe(sample_df.style.format({
                'Prix Réel': '${:,.0f}',
                'Prix Prédit': '${:,.0f}',
                'Erreur': '${:,.0f}',
                'Erreur (%)': '{:.1f}%'
            }))
    
    else:
        st.warning(" Les données de test et prédictions ne sont pas disponibles.")
        st.info("Assurez-vous d'avoir :")
        st.markdown("""
        1. Un fichier `test_clean.csv` ou `test.csv` avec la colonne SalePrice
        2. Le fichier `preprocessor.joblib` 
        3. Le fichier `best_model.joblib` ou `best_xgboost.joblib`
        
        **OU**
        
        Les fichiers :
        - `y_test_log.npy`
        - `y_pred_xgboost_log.npy`
        """)
        
        # Afficher ce qui est disponible
        st.subheader("Statut du chargement :")
        st.write(f"- Préprocesseur chargé : {'preprocessor' in model_data}")
        st.write(f"- Modèle chargé : {'model' in model_data}")
        st.write(f"- y_test disponible : {'y_test' in model_data}")
        st.write(f"- y_pred disponible : {'y_pred' in model_data}")
    
    # Feature Importance
    st.markdown("---")
    st.subheader(" Importance des Variables")
    
    if model_data.get('importance') is not None:
        importance_df = model_data['importance']
        
        if isinstance(importance_df, pd.DataFrame) and 'feature' in importance_df.columns and 'importance' in importance_df.columns:
            top_10 = importance_df.sort_values('importance', ascending=False).head(10)
            
            fig_imp = px.bar(
                top_10,
                x='importance',
                y='feature',
                orientation='h',
                title='Top 10 des Variables les Plus Importantes (XGBoost)',
                color='importance',
                color_continuous_scale='Viridis'
            )
            fig_imp.update_layout(
                height=400,
                yaxis={'categoryorder': 'total ascending'}
            )
            st.plotly_chart(fig_imp, use_container_width=True)
        else:
            st.warning("Le format du fichier d'importance n'est pas correct")
    else:
        st.info(" Les données d'importance des features ne sont pas disponibles")
# ============================================================================
# PAGE 5 : SIMULATEUR
# ============================================================================
elif page == "Simulateur":
    st.title(" Simulateur de Prix de Maison")
    
    if model_data is None or model_data.get('model') is None:
        st.error(" Le modèle XGBoost n'est pas chargé.")
        
        with st.expander(" Pourquoi ?"):
            st.markdown("""
            Le simulateur nécessite le modèle XGBoost pour fonctionner.
            
            **Vérifiez :**
            1. Le fichier `output/models/best_xgboost.joblib` existe
            2. Le modèle a été correctement entraîné
            3. Les chemins d'accès sont corrects
            
            **Emplacement attendu :**
            ```
            C:/Users/user/Desktop/ISE2_2026/ML/dashboard/output/models/best_xgboost.joblib
            ```
            """)
        
        # Afficher la structure actuelle
        current_dir = Path(__file__).parent.absolute()
        st.write(f"**Répertoire courant :** {current_dir}")
        
        models_dir = current_dir / "output" / "models"
        st.write(f"**Dossier des modèles :** {models_dir}")
        
        if models_dir.exists():
            st.write("**Fichiers trouvés :**")
            for file in models_dir.glob("*"):
                st.write(f"  - {file.name}")
        else:
            st.write(" Le dossier des modèles n'existe pas")
            
        st.stop()
    
    if df_raw.empty:
        st.error(" Les données de référence ne sont pas chargées")
        st.stop()
    
    st.markdown("Estimez le prix d'une maison en fonction de ses caractéristiques.")
    st.markdown("---")
    
    model = model_data['model']
    
    # Formulaire interactif
    with st.form("house_prediction_form"):
        st.subheader(" Caractéristiques de la Maison")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Variables quantitatives principales
            gr_liv_area = st.slider(
                "Surface Habitable (GrLivArea) [sqft]",
                min_value=int(df_raw['GrLivArea'].min()),
                max_value=int(df_raw['GrLivArea'].max()),
                value=int(df_raw['GrLivArea'].median()),
                step=50
            )
            
            total_bsmt_sf = st.slider(
                "Surface du Sous-sol (TotalBsmtSF) [sqft]",
                min_value=int(df_raw['TotalBsmtSF'].min()),
                max_value=int(df_raw['TotalBsmtSF'].max()),
                value=int(df_raw['TotalBsmtSF'].median()),
                step=50
            )
            
            overall_qual = st.slider(
                "Qualité Générale (OverallQual)",
                min_value=int(df_raw['OverallQual'].min()),
                max_value=int(df_raw['OverallQual'].max()),
                value=int(df_raw['OverallQual'].median()),
                step=1,
                help="1=Très Pauvre, 10=Très Excellent"
            )
        
        with col2:
            garage_cars = st.slider(
                "Nombre de Places de Garage (GarageCars)",
                min_value=int(df_raw['GarageCars'].min()),
                max_value=int(df_raw['GarageCars'].max()),
                value=int(df_raw['GarageCars'].median()),
                step=1
            )
            
            year_built = st.slider(
                "Année de Construction (YearBuilt)",
                min_value=int(df_raw['YearBuilt'].min()),
                max_value=int(df_raw['YearBuilt'].max()),
                value=int(df_raw['YearBuilt'].median()),
                step=1
            )
            
            full_bath = st.slider(
                "Nombre de Salles de Bain (FullBath)",
                min_value=int(df_raw['FullBath'].min()),
                max_value=int(df_raw['FullBath'].max()),
                value=int(df_raw['FullBath'].median()),
                step=1
            )
        
        # Variables qualitatives
        col1, col2 = st.columns(2)
        
        with col1:
            kitchen_qual = st.selectbox(
                "Qualité de la Cuisine (KitchenQual)",
                options=unique_vals['kitchen_quals'] if unique_vals['kitchen_quals'] else ['TA', 'Gd', 'Ex', 'Fa'],
                help="Ex=Excellent, Gd=Good, TA=Typical/Average, Fa=Fair"
            )
            
            neighborhood = st.selectbox(
                "Quartier (Neighborhood)",
                options=unique_vals['neighborhoods'] if unique_vals['neighborhoods'] else ['NAmes', 'CollgCr', 'OldTown', 'Edwards'],
                help="Quartier de la maison"
            )
        
        with col2:
            exterior_qual = st.selectbox(
                "Qualité Extérieure (ExterQual)",
                options=unique_vals['exterior_quals'] if unique_vals['exterior_quals'] else ['TA', 'Gd', 'Ex', 'Fa'],
                help="Qualité du matériau extérieur"
            )
            
            house_style = st.selectbox(
                "Style de Maison (HouseStyle)",
                options=unique_vals['house_styles'] if unique_vals['house_styles'] else ['1Story', '2Story', '1.5Fin'],
                help="Style architectural"
            )
        
        submit_button = st.form_submit_button(" Estimer le Prix", use_container_width=True)
    
    if submit_button:
        try:
            # Créer une ligne de données pour la prédiction
            input_data = {
                'GrLivArea': gr_liv_area,
                'TotalBsmtSF': total_bsmt_sf,
                'OverallQual': overall_qual,
                'GarageCars': garage_cars,
                'YearBuilt': year_built,
                'FullBath': full_bath,
                'KitchenQual': kitchen_qual,
                'Neighborhood': neighborhood,
                'ExterQual': exterior_qual,
                'HouseStyle': house_style,
                # Ajouter des valeurs par défaut pour les autres features
                'BedroomAbvGr': 3,
                'TotRmsAbvGrd': 6,
                'Fireplaces': 1,
                'GarageArea': garage_cars * 200,
                'WoodDeckSF': 0,
                'OpenPorchSF': 50,
                'EnclosedPorch': 0,
                'ScreenPorch': 0,
                'MoSold': 6,
                'YrSold': 2010,
                'LotArea': 8000,
                'YearRemodAdd': year_built,
                'MasVnrArea': 0,
                'BsmtFinSF1': total_bsmt_sf * 0.5,
                'BsmtUnfSF': total_bsmt_sf * 0.3,
                'TotalRmsAbvGrd': 6,
                'GarageYrBlt': year_built,
                'GarageQual': 'TA',
                'GarageCond': 'TA',
                'PavedDrive': 'Y',
                'CentralAir': 'Y',
                'HeatingQC': 'Ex',
                'Electrical': 'SBrkr',
                'BsmtQual': 'TA',
                'BsmtCond': 'TA',
                'Foundation': 'PConc',
                'BsmtExposure': 'No',
                'BsmtFinType1': 'Unf',
                'BsmtFinType2': 'Unf',
                'RoofStyle': 'Gable',
                'RoofMatl': 'CompShg',
                'Exterior1st': 'VinylSd',
                'Exterior2nd': 'VinylSd',
                'MasVnrType': 'None',
                'ExterCond': 'TA',
                'BsmtFullBath': 0,
                'BsmtHalfBath': 0,
                'HalfBath': 1,
                'KitchenAbvGr': 1,
                'TotRmsAbvGrd': 6,
                'Functional': 'Typ',
                'Fireplaces': 1,
                'FireplaceQu': 'Gd',
                'GarageType': 'Attchd',
                'GarageFinish': 'Unf',
                'GarageQual': 'TA',
                'GarageCond': 'TA',
                'PavedDrive': 'Y',
                'PoolArea': 0,
                'Fence': 'None',
                'MiscFeature': 'None',
                'SaleType': 'WD',
                'SaleCondition': 'Normal',
                'LotFrontage': 60,
                'LotShape': 'Reg',
                'LandContour': 'Lvl',
                'Utilities': 'AllPub',
                'LotConfig': 'Inside',
                'LandSlope': 'Gtl',
                'Condition1': 'Norm',
                'Condition2': 'Norm',
                'BldgType': '1Fam',
                'HouseStyle': house_style,
                'OverallCond': 5,
                'MSSubClass': 60,
                'MSZoning': 'RL',
                'Street': 'Pave',
                'Alley': 'None',
                'LotShape': 'Reg',
                'LandContour': 'Lvl',
                'LotConfig': 'Inside',
                'LandSlope': 'Gtl',
                'Neighborhood': neighborhood,
                'Condition1': 'Norm',
                'Condition2': 'Norm',
                'BldgType': '1Fam',
                'HouseStyle': house_style,
                'RoofStyle': 'Gable',
                'RoofMatl': 'CompShg',
                'Exterior1st': 'VinylSd',
                'Exterior2nd': 'VinylSd',
                'MasVnrType': 'None',
                'ExterQual': exterior_qual,
                'ExterCond': 'TA',
                'Foundation': 'PConc',
                'BsmtQual': 'TA',
                'BsmtCond': 'TA',
                'BsmtExposure': 'No',
                'BsmtFinType1': 'Unf',
                'BsmtFinType2': 'Unf',
                'Heating': 'GasA',
                'HeatingQC': 'Ex',
                'CentralAir': 'Y',
                'Electrical': 'SBrkr',
                'KitchenQual': kitchen_qual,
                'Functional': 'Typ',
                'FireplaceQu': 'Gd',
                'GarageType': 'Attchd',
                'GarageFinish': 'Unf',
                'GarageQual': 'TA',
                'GarageCond': 'TA',
                'PavedDrive': 'Y',
                'PoolQC': 'None',
                'Fence': 'None',
                'MiscFeature': 'None',
                'SaleType': 'WD',
                'SaleCondition': 'Normal'
            }
            
            # Convertir en DataFrame
            input_df = pd.DataFrame([input_data])
            
            # IMPORTANT: S'assurer que toutes les colonnes du modèle sont présentes
            # Pour l'instant, nous allons faire une prédiction simplifiée
            st.info(" Note: Cette prédiction utilise des valeurs par défaut pour les variables manquantes.")
            
            # Pour une vraie prédiction, vous auriez besoin de :
            # 1. Charger le pipeline complet (prétraitement + modèle)
            # 2. Appliquer le même encodage que pendant l'entraînement
            
            # Estimation basée sur les variables principales seulement
            # (Ceci est une approximation - pour une vraie prédiction, utilisez le pipeline complet)
            base_price = 100000
            price = base_price + (gr_liv_area * 50) + (total_bsmt_sf * 30) + (overall_qual * 10000)
            price += garage_cars * 5000 + ((2024 - year_built) * -1000)
            
            # Ajustement pour la qualité
            qual_adjustments = {'Ex': 30000, 'Gd': 15000, 'TA': 0, 'Fa': -10000, 'Po': -20000}
            price += qual_adjustments.get(kitchen_qual, 0)
            price += qual_adjustments.get(exterior_qual, 0)
            
            st.success(f"##  Prix estimé : **${price:,.0f}**")
            
            # Comparaison avec le marché
            with st.expander(" Comparaison avec le marché"):
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Votre estimation", f"${price:,.0f}")
                    st.metric("Prix moyen du marché", f"${avg_price:,.0f}")
                with col2:
                    diff = price - avg_price
                    diff_pct = (diff / avg_price) * 100
                    st.metric("Différence", f"${diff:,.0f}", f"{diff_pct:+.1f}%")
                    
                    if diff_pct > 20:
                        st.warning(" Cette estimation est significativement au-dessus du marché")
                    elif diff_pct < -20:
                        st.info(" Cette estimation est significativement en dessous du marché")
                    else:
                        st.success(" Cette estimation est dans la fourchette du marché")
            
        except Exception as e:
            st.error(f" Erreur lors de l'estimation: {str(e)}")
            import traceback
            with st.expander(" Détails de l'erreur"):
                st.code(traceback.format_exc())

# ============================================================================
# PAGE 6 : PRÉDICTIONS
# ============================================================================
elif page == "Prédictions":
    st.title(" Prédictions du prix des maisons")
    
    if model_data is None:
        st.error(" Les données du modèle ne sont pas chargées")
        st.stop()
    
    submission_df = model_data.get('submission')
    
    if submission_df is None:
        st.warning(" Aucun fichier de prédictions disponible")
        
        # Vérifier si le fichier existe
        current_dir = Path(__file__).parent.absolute()
        submission_path = current_dir / "output" / "predictions" / "kaggle_submission_xgboost.csv"
        
        if submission_path.exists():
            st.info(f" Le fichier existe à: {submission_path}")
            try:
                submission_df = pd.read_csv(submission_path)
                st.success(" Fichier chargé avec succès!")
            except Exception as e:
                st.error(f" Erreur de chargement: {e}")
        else:
            st.error(f" Fichier non trouvé: {submission_path}")
            st.info("Vérifiez que le fichier existe à cet emplacement")
        
        st.stop()
    
    st.markdown("Visualisez et téléchargez les prédictions pour la soumission Kaggle.")
    st.markdown("---")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.subheader(" Aperçu des Prédictions")
        st.write(f"**Nombre de prédictions :** {len(submission_df):,}")
        
        # Afficher les premières lignes
        st.dataframe(
            submission_df.head(10).style.format({'SalePrice': '${:,.0f}'}),
            use_container_width=True
        )
        
        # Statistiques rapides
        st.markdown("---")
        st.subheader(" Statistiques")
        
        if 'SalePrice' in submission_df.columns:
            st.metric("Prix Moyen Prédit", f"${submission_df['SalePrice'].mean():,.0f}")
            st.metric("Prix Médian Prédit", f"${submission_df['SalePrice'].median():,.0f}")
            st.metric("Prix Minimum", f"${submission_df['SalePrice'].min():,.0f}")
            st.metric("Prix Maximum", f"${submission_df['SalePrice'].max():,.0f}")
        
        # Téléchargement
        st.markdown("---")
        st.subheader(" Téléchargement")
        
        csv = submission_df.to_csv(index=False)
        st.download_button(
            label=" Télécharger submission.csv",
            data=csv,
            file_name="submission_xgboost.csv",
            mime="text/csv",
            use_container_width=True
        )
    
    with col2:
        st.subheader(" Distribution des Prix Prédits")
        
        if 'SalePrice' in submission_df.columns:
            fig = px.histogram(
                submission_df, 
                x='SalePrice',
                nbins=50,
                title='Distribution des Prix Prédits',
                labels={'SalePrice': 'Prix Prédit ($)'},
                color_discrete_sequence=['#17becf']
            )
            
            # Ajouter lignes de moyenne et médiane
            mean_price = submission_df['SalePrice'].mean()
            median_price = submission_df['SalePrice'].median()
            
            fig.add_vline(
                x=mean_price, 
                line_dash="dash", 
                line_color="red",
                annotation_text=f"Moyenne: ${mean_price:,.0f}"
            )
            
            fig.add_vline(
                x=median_price, 
                line_dash="dash", 
                line_color="green",
                annotation_text=f"Médiane: ${median_price:,.0f}"
            )
            
            fig.update_layout(height=500)
            st.plotly_chart(fig, use_container_width=True)
            
            # Box plot
            with st.expander(" Box Plot des Prix"):
                fig_box = px.box(
                    submission_df,
                    y='SalePrice',
                    title='Box Plot des Prix Prédits',
                    labels={'SalePrice': 'Prix Prédit ($)'}
                )
                fig_box.update_layout(height=400)
                st.plotly_chart(fig_box, use_container_width=True)
        else:
            st.error("La colonne 'SalePrice' est manquante dans le fichier de prédictions")
